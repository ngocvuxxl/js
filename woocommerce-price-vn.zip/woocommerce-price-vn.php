<?php
/**
 * Plugin Name: WooCommerce Price VN
 * Description: Hiển thị dạng chữ thay vì dạng số cho sản phẩm WooCommerce
 * Version: 1.0 
 * Author: ngocvuxxl
 * Author URI: https://ngocvuxxl.net
 * License: GPLv2 or later
 */

add_filter('woocommerce_price_html','rei_woocommerce_price_html', 10, 2);
add_filter('woocommerce_sale_price_html','rei_woocommerce_price_html', 10, 2);
function rei_woocommerce_price_html($price, $product) {

    $currency = get_woocommerce_currency_symbol( );
    $price = $currency . custom_number_format($product->get_price(),3);

    return $price;
}

function custom_number_format($n, $precision) {
    if ($n < 1000000 && $n >= 100000) {
        if (isset($options['woocommerce_price_vn_hundred']) && $options['woocommerce_price_vn_hundred'] != '') 
			$n_format = number_format($n / 100000, $precision) . ' ' . $options['woocommerce_price_vn_hundred'];
    } else if ($n < 1000000000) {
        if (isset($options['woocommerce_price_vn_million']) && $options['woocommerce_price_vn_million'] != '') 
			$n_format = number_format($n / 1000000, $precision) . ' ' . $options['woocommerce_price_vn_million'];
    } else {
        if (isset($options['woocommerce_price_vn_billion']) && $options['woocommerce_price_vn_billion'] != '') 
			$n_format = number_format($n / 1000000000, $precision) . ' ' . $options['woocommerce_price_vn_billion'];
    }

    return $n_format;
}

add_action('admin_menu', 'woocommerce_price_vn');
add_action('admin_init', 'woocommerce_price_vn_register_settings');

function woocommerce_price_vn_register_settings(){
    register_setting('woocommerce_price_vn_settings', 'woocommerce_price_vn_settings', 'woocommerce_price_vn_settings_validate');
}

function woocommerce_price_vn_settings_validate($args){
    return $args;
}

add_action('admin_notices', 'woocommerce_price_vn_admin_notices');
function woocommerce_price_vn_admin_notices(){
   settings_errors();
}

function woocommerce_price_vn(){
    add_menu_page( 'WooCommerce Price VN', 'WooCommerce Price VN', 'manage_options', 'woocommerce-price-vn', 'woocommerce_price_vn_init' );
}

function woocommerce_price_vn_init() {
	?>
	<h1>Import Thành Viên Từ File Excel</h1>
	<div id="main">
		<form action="options.php" method="post"><?php
        settings_fields( 'woocommerce_price_vn_settings' );
        do_settings_sections( __FILE__ );

        //get the older values, wont work the first time
        $options = get_option( 'woocommerce_price_vn_settings' ); ?>
        <table class="form-table">
            <tr>
                <th scope="row">Hàng trăm ngàn</th>
                <td>
                    <fieldset>
                        <label>
                            <input name="woocommerce_price_vn_settings[woocommerce_price_vn_hundred]" type="text" id="woocommerce_price_vn_hundred" value="<?php echo (isset($options['woocommerce_price_vn_hundred']) && $options['woocommerce_price_vn_hundred'] != '') ? $options['woocommerce_price_vn_hundred'] : ''; ?>"/>
                        </label>
                    </fieldset>
                </td>
            </tr>
			<tr>
                <th scope="row">Hàng triệu</th>
                <td>
                    <fieldset>
                        <label>
                            <input name="woocommerce_price_vn_settings[woocommerce_price_vn_million]" type="text" id="woocommerce_price_vn_million" value="<?php echo (isset($options['woocommerce_price_vn_million']) && $options['woocommerce_price_vn_million'] != '') ? $options['woocommerce_price_vn_million'] : ''; ?>"/>
                        </label>
                    </fieldset>
                </td>
            </tr>
			<tr>
                <th scope="row">Hàng tỉ</th>
                <td>
                    <fieldset>
                        <label>
                            <input name="woocommerce_price_vn_settings[woocommerce_price_vn_billion]" type="text" id="woocommerce_price_vn_billion" value="<?php echo (isset($options['woocommerce_price_vn_billion']) && $options['woocommerce_price_vn_billion'] != '') ? $options['woocommerce_price_vn_billion'] : ''; ?>"/>
                        </label>
                    </fieldset>
                </td>
            </tr>
        </table>
        <input type="submit" value="Save" />
    </form>
	</div>
<?php
}